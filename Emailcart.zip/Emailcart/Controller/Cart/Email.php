<?php
namespace Infoeverysolution\Emailcart\Controller\Cart;
 use Magento\Framework\App\Action\Context;
use Magento\Framework\App\RequestInterface;
use \Magento\Framework\Mail\Template\TransportBuilder;
use \Magento\Framework\Translate\Inline\StateInterface;
use Psr\Log\LoggerInterface;
 
class Email extends \Magento\Framework\App\Action\Action
{
    /**
     * Recipient email config path
     */
    const XML_PATH_EMAIL_RECIPIENT = 'test/email/send_email';
    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;
	
	

    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $inlineTranslation;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
	
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var \Magento\Framework\Escaper
     */


    protected $_escaper;
    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Escaper $escaper
    ) {
        parent::__construct($context);
        $this->_transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_escaper = $escaper;
    }

    /**
     * Post user question
     *
     * @return void
     * @throws \Exception
     */
    public function execute()
    {
 $postdata =  $this->getRequest()->getPostValue();
	$adminemail = $postdata['adminemail'];
	$smartemail = $postdata['smartemail'];
	$smartname = $postdata['smartname'];
	$smartmsg = $postdata['smartmsg'];

	$invitename = $postdata['invitename'];
	$inviteemail = $postdata['inviteemail'];


	
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		/*  Cart info get  */
		 $cart = $objectManager->get('\Magento\Checkout\Model\Cart'); 
		 $items = $cart->getQuote()->getAllItems();
         $productRepository = $objectManager->get('\Magento\Catalog\Model\ProductRepository');
		 // retrieve quote items collection
		$itemsCollection = $cart->getQuote()->getItemsCollection();
 
// get array of all items what can be display directly
			 $itemsVisible = $cart->getQuote()->getAllVisibleItems();
			 
			 		 /*  get value from the admin */
			 
 $emailtemplatetext  = $this->_objectManager->create('Infoeverysolution\Emailcart\Helper\Data')->getConfig('TDM_TDMemailcart/general/pickup_template');

 if(empty($emailtemplatetext))
 {
	 $emailtemplatetext ="custom_email_template";
	 
 }
	 $pricing  = $this->_objectManager->create('Infoeverysolution\Emailcart\Helper\Data')->getConfig('TDM_TDMemailcart/general/pricing');
	
	
	
			 $allcartItem = array();
			 foreach($items as $item) { 
				 $pname =$item->getName();
				 $Id  =$item->getId();
				 $qty = $item->getQty();
				 $sku = $item->getSku();
				 $price = $item->getPrice();
				$option = $item->getProductOptions();
			  // $product = $productRepository->get($sku);
			   $url = $item->getProductUrl();
			   
			   
			  /*  $ID = $product->getId();
			   $_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			   $product = $_objectManager->get('\Magento\Catalog\Model\Product')->load($ID);
			$customOptions = $_objectManager->get('Magento\Catalog\Model\Product\Option')->getProductOptionCollection($product);
			
          $customOptions = $this->_objectManager->get('Magento\Catalog\Model\Product\Option')->getProductOptionCollection($product); */


			$item = array('pname'=>$pname,'qty'=>$qty,'sku'=>$sku,'price'=>$price,'url'=>$url,'pricing'=>$pricing);
			 
			array_push($allcartItem,$item);
					   }
					   
					
					   
		    $sender = [
                'name' => $this->_escaper->escapeHtml($smartname),
                'email' => $this->_escaper->escapeHtml($smartemail),
            ];
			/*  Email send commom  */
		     $error = false;
		$postObject = new \Magento\Framework\DataObject();
		
	    $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
		
		/*  Send email to sender */
		
			$smartemail = $postdata['smartemail'];
			$smartname = $postdata['smartname'];
			
			
			if(isset($postdata['sendtome']))
			{
			
           $post =array('productdetail'=>json_encode($allcartItem),'name'=>$smartname,'senderemail'=>$smartemail,'sendername'=>$smartname,"email"=>$smartemail,'smartmsg'=>$smartmsg);
			 
			   try {
            $postObject->setData($post);
           $this->inlineTranslation->suspend();
            $transport = $this->_transportBuilder
                ->setTemplateIdentifier($emailtemplatetext) // this code we have mentioned in the email_templates.xml
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_ADMINHTML, // this is using frontend area to get the template file
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )
                ->setTemplateVars(['data' => $postObject])
                ->setFrom($sender)
                ->addTo($smartemail)
                ->getTransport();
            $transport->sendMessage(); ;
            $this->inlineTranslation->resume();
            $this->messageManager->addSuccess(
                __('Your cart info send successfully to your self')
            );
			echo "\n Your cart info send successfully to your self";
            //$this->_redirect('*/*/');
          
        } catch (\Exception $e) {
            $this->inlineTranslation->resume();
            $msg =  $this->messageManager->addError(
                __('We can\'t process your request right now. Sorry, that\'s all we know.'.$e->getMessage())
            );
				print_r($e->getMessage());
		}
			}
		
		
		/* Send mail to invitee*/
		if(!empty($inviteemail))
		{
	
	foreach($inviteemail as $key=>$inemail)
	{
		 $inviteemail = $inemail;
      $invitenames= $invitename[$key];
	  

	  
	  $post =array('productdetail'=>json_encode($allcartItem),'name'=>$invitenames,'senderemail'=>$smartemail,'sendername'=>$smartname,"email"=>$inviteemail,'smartmsg'=>$smartmsg);
			 
			   try {
            $postObject->setData($post);
           $this->inlineTranslation->suspend();
            $transport = $this->_transportBuilder
                ->setTemplateIdentifier($emailtemplatetext) // this code we have mentioned in the email_templates.xml
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_ADMINHTML, // this is using frontend area to get the template file
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )
                ->setTemplateVars(['data' => $postObject])
                ->setFrom($sender)
                ->addTo($inviteemail)
                ->getTransport();
            $transport->sendMessage(); ;
            $this->inlineTranslation->resume();
            $this->messageManager->addSuccess(
                __('Your cart info send successfully to Invtee'.$invitenames)
            );
			echo "\n Your cart info send successfully to Invtee ".$invitenames;
            //$this->_redirect('*/*/');
          
        } catch (\Exception $e) {
            $this->inlineTranslation->resume();
            $msg =  $this->messageManager->addError(
                __('We can\'t process your request right now. Sorry, that\'s all we know.'.$e->getMessage())
            );
				print_r($e->getMessage());
		}
		
	}	
		}
		   /*  If checkbox is clicked */
			
			if(isset($postdata['sendcopy']))
			{
				
				  $name = $postdata['adminname'];
				 $email = $postdata['adminemail']; 
    $post =array('productdetail'=>json_encode($allcartItem),'name'=>$name,"email"=>$email,'senderemail'=>$smartemail,'sendername'=>$smartname,'smartmsg'=>$smartmsg);
			 
			   try {
            $postObject->setData($post);
           $this->inlineTranslation->suspend();
            $transport = $this->_transportBuilder
                ->setTemplateIdentifier($emailtemplatetext) // this code we have mentioned in the email_templates.xml
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_ADMINHTML, // this is using frontend area to get the template file
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )
                ->setTemplateVars(['data' => $postObject])
                ->setFrom($sender)
                ->addTo($email)
                ->getTransport();
            $transport->sendMessage(); ;
            $this->inlineTranslation->resume();
            $this->messageManager->addSuccess(
                __('Your cart info send successfully to company')
            );
			echo "\n Your cart info send successfully to company";
            //$this->_redirect('*/*/');
          
        } catch (\Exception $e) {
            $this->inlineTranslation->resume();
            $msg =  $this->messageManager->addError(
                __('We can\'t process your request right now. Sorry, that\'s all we know.'.$e->getMessage())
            );
			
		
			
			
            //$this->_redirect('*/*/');
          //  return;
        }
			 
			}
			
	
      
      
		
		
    }
}