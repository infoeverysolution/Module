define(
    [
        'jquery',
        'Magento_Ui/js/modal/modal',
		'underscore',
		'mage/template',
		'mage/url',
		'mage/mage'
    ],

    function($) {
        "use strict";
        //creating jquery widget
          $("#modal-form").hide();
		  
	  $(".addinvitee").click(function()
	  {
		  
$(".invitee-add").append('</hr><div class="form-group"><div class="label">Name</div><div class="label-field"><input type="text" name="invitename[]"  class="validate-length maximum-length-50 input-text" "validate-length":true}></div></div><div class="form-group"><div class="label">Email</div><div class="label-field"><input type="email" class="validate-length maximum-length-100 input-email" "validate-length":true} name="inviteemail[]"></div></div>');
		  
	  });	  
		  var dataForm = $('#sendsmartmail');
                           dataForm.mage('validation', {});
        $.widget('Vendor.modalForm', {
            options: {
                modalForm: '#modal-form',
                modalButton: '.open-modal-form'
            },
            _create: function() {
                this.options.modalOption = this._getModalOptions();
                this._bind();
            },
            _getModalOptions: function() {
                /**
                 * Modal options
                 */
                var options = {
                    type: 'popup',
                    responsive: true,
                    title: 'Email Your Shoping Cart',
                    buttons: [{
                        text: $.mage.__('Send Email'),
                        class: '',
                        click: function () {
					        var param = $("#sendsmartmail").serialize();
							var mailsendAction  =baseUrl+'emailcart/cart/email';
							
						 if($('#sendsmartmail').valid())
						 {
						 $.ajax({
                                showLoader: true,
                                url: mailsendAction,
                                data: param,
                                type: "POST"
                            }).done(function (data) {
								alert(data);
					$(".modal-content").html('Your cart has been emailed. Thank you');
					$(".modal-footer").hide();
					
					setTimeout(function() { location.reload(); }, 2000);
							   
                            });
						 }
						
						 
						
                        }
                    }]
                };

                return options;
            },
            _bind: function(){
                var modalOption = this.options.modalOption;
                var modalForm = this.options.modalForm;

                $(document).on('click', this.options.modalButton,  function(){
                    //Initialize modal
                    $(modalForm).modal(modalOption);
                    //open modal
                    $(modalForm).trigger('openModal');
                });
            }
        });

        return $.Vendor.modalForm;
    }
);