Overview:
This extension is used to send cart detail to email for invitee, admin and myelf. user can send email to infinite invitee

Install the Extension;

Step 1.

To install the extension, you have to extract the zip and upload in magento path in app/code folder, if code foolder is not available, please first create the code folder.

Step 2: Run upgrade magento command, give below

php bin/magento setup:upgrade

Step 3 : Clear magento cache, you can run following command:

php bin/magento cache:clean
php bin/magento cache:flush

After this run one more command:

php bin/magento indexer:reindex

Now your extension is installed, you can see the 'Email shopping cart' button on frontend on cart page.

 
 

